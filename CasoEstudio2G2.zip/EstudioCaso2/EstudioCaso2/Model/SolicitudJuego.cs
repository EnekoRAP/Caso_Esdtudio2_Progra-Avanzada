﻿namespace EstudioCaso2.Model
{
    public class SolicitudJuego
    {
        public string Jugador1 { get; set; }
        public string Jugador2 { get; set; }
        public string Color1 { get; set; }
        public string Color2 { get; set; }
    }
}