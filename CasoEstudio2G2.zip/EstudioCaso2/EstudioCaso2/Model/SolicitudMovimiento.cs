﻿namespace EstudioCaso2.Model
{
    public class SolicitudMovimiento
    {
        public int Columna { get; set; }
    }
}